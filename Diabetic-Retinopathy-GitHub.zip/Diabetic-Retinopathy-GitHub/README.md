# Diabetic Retinopathy — Dataset Browser & Predictor

This GitHub package uses the **original `DibeticRetinopathy.py` and `train.py` files supplied by the project owner**. The Python source files have been copied as provided, without replacing their implementation.

The Streamlit app supports:
- Downloading/locating the APTOS 2019 dataset through `kagglehub`
- Browsing images by diabetic retinopathy severity
- Predicting an uploaded retinal image using a saved Keras or TensorFlow Lite model
- Showing class scores for five labels

## Project structure

```text
Diabetic-Retinopathy-GitHub/
├── DibeticRetinopathy.py
├── train.py
├── requirements.txt
├── README.md
├── .gitignore
├── model/
│   └── PUT_MODEL_FILES_HERE.txt
└── results/
    └── .gitkeep
```

## Requirements

- Python installed on your computer
- Internet access for downloading dependencies and (when not already cached) the APTOS dataset
- The project's trained model file for predictions

## Run the existing app on Windows

Open PowerShell in this project folder. Install dependencies:

```powershell
python -m pip install -r requirements.txt
```

Place your existing model file(s) in the `model` folder, then start the app:

```powershell
python -m streamlit run DibeticRetinopathy.py
```

The app should display a local URL in the terminal, usually `http://localhost:8501`.

### Model files expected by the original app

The original application checks these exact paths:

- `model/dr_mobilenetv2.h5`
- `model/dr_mobilenetv2_int8.tflite`

The original training script saves the best checkpoint as `model/best_model.keras` and then saves the final model as `model/dr_mobilenetv2.h5`. **The app does not automatically load `best_model.keras`** unless the app code is changed; to keep the original code unchanged, place `dr_mobilenetv2.h5` in `model/` for Keras prediction. The TFLite file is optional and is only available if you have already generated it.

The model binaries were not included in this package because only the two Python source files were uploaded in chat. Copy your existing model files into `model/` locally. Avoid committing large model files to GitHub unless you intend to use Git LFS or another model-hosting option.

## Dataset behavior

The app calls `kagglehub.dataset_download("mariaherrerot/aptos2019")` to locate/download the dataset. It expects a CSV (`train.csv` or `train_1.csv`) and a `train_images` directory somewhere under the downloaded dataset folder.

The original `train.py` uses a Windows-specific Kaggle cache path:

```text
~\.cache\kagglehub\datasets\mariaherrerot\aptos2019\versions\3
```

If training cannot find the dataset on your machine, check that this path exists or update `DATASET_ROOT` in `train.py` to the actual dataset location. Training will start from scratch; use it only if you intend to retrain.

## Current implementation status

- **Implemented in original code:** Streamlit dataset browser, class-distribution chart, severity filtering, image upload, Keras/TFLite inference paths, MobileNetV2 training pipeline, class weights, checkpoint saving.
- **Not included here:** Actual model binaries, APTOS dataset, trained output files, and any TFLite conversion script.

## Reported experiment results

Previously reported initial results for this project were: 2,344 training images, 586 validation images, best validation accuracy 60.07% (Epoch 3), final validation accuracy 57.34% (Epoch 5), and final validation loss 1.052. These historical numbers are not recomputed by this repository package.

## Important medical disclaimer

This is an educational/research prototype, not a clinically validated medical device. It must not be used to diagnose diabetic retinopathy or guide treatment. Consult a qualified eye-care professional for health concerns.

## Dataset and model licensing

Check the APTOS dataset terms and the licenses for pretrained weights and libraries before redistributing them.
